const Piece = require('./piece');


module.exports = {
    Piece,
}