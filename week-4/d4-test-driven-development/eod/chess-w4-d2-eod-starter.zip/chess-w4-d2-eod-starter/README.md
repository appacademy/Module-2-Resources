# Module 2 Chess EOD - W4D2

Use the specs to help guide you in finishing the Chess pieces. Think about how 
each piece would interact on the board, with pieces of the same team, and with
a piece on the opposing team. 

The game Board and Squares from EOD have been provided to aid in testing.

To run the specs run `npm test test/<pieceName>.js`