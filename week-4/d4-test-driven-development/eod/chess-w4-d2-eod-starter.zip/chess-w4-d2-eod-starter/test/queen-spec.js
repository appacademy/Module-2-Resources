// BONUS
// Try to figure out how to test the Queen class. Use the other specs to help
// guide you.